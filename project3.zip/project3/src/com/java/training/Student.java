package com.java.training;

public class Student implements Comparable<Student> {
	private String name;
	private String city;
	private Integer studId;
	
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(String name, String city, Integer studId) {
		super();
		this.name = name;
		this.city = city;
		this.studId = studId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Integer getStudId() {
		return studId;
	}
	public void setEmpId(Integer studId) {
		this.studId = studId;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", city=" + city + ", studId=" + studId + "]";
	}
	@Override
	public int compareTo(Student student) {
		// TODO Auto-generated method stub
		return this.getCity().compareTo(student.getCity());
	}
	
	
}
