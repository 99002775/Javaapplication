package com.java.training;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class SortTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student1 = new Student("Divya","Tiruvallur",101);
		Student student2 = new Student("Ashwin","coimbatore",103);;
		Student student3 = new Student("karthi","Chennai",102);
		Student student4 = new Student("Nila","Ooty",104);
		Student student5 = new Student("diya","banglore",105);
		
		ArrayList<Student> studentList = new ArrayList<>();
		studentList.add(student1);
		studentList.add(student2);
		studentList.add(student3);
		studentList.add(student4);
		studentList.add(student5);
		
		for (Student stud : studentList) {
			System.out.println(stud);
		}
		
		//sort using comparator
		Collections.sort(studentList, new NameSort());
		System.out.println("/////////Sorted by name///////////");
		for (Student stud :  studentList) {
			System.out.println(stud);
		}
		
		Collections.sort(studentList, new Comparator<Student>() {

			@Override
			public int compare(Student student1, Student employ2) {
				// TODO Auto-generated method stub
				return student1.getCity().compareTo(student2.getCity());
			}
			
		});
		System.out.println("/////////Sorted by city///////////");
		for (Student stud : studentList) {
			System.out.println(stud);
		}
		
		Collections.sort(studentList,(stud1,stud2)->{
			return stud1.getStudId().compareTo(stud2.getStudId());
			
		});
		
		System.out.println("/////////Sorted by Employee ID///////////");
		for (Student stud : studentList) {
			System.out.println(stud);
		}
		

	}

}
