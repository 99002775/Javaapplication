package com.hotelapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;


import com.hotelapp.model.Hotel;
import com.hotelapp.service.HotelService;

@RestController
public class HotelController {
	@Autowired
HotelService hotelService;
	@GetMapping("/hotel")
	public List<Hotel> showAllHotels(){
		return hotelService.getAllHotels();
	}
	@GetMapping("/hotel-by-name/{name}")
	public List<Hotel> showHotelsByNmae(@PathVariable("name")String name){
		return hotelService.getByHotelName(name);
	}
	@GetMapping("/hotel-by-city/{city}")
	public List<Hotel> showHotelsByCity(@PathVariable("city")String city){
		return hotelService.getBycity(city);
	}
	@GetMapping("/hotel-by-id/{hotelid}")
	public Hotel showHotelById(@PathVariable("hotelid")int  id) {
	return hotelService.getById(id);
	}
	@GetMapping("/hotel-by-cuisine/{cuisine}")
	public List<Hotel> showHotelsByCuisine(@PathVariable("cuisine")String cuisine){
		return hotelService.getByCuisine(cuisine);
	}
}
