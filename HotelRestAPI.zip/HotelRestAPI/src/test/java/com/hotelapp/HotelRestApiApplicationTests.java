package com.hotelapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
