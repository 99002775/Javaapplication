package com.java.training;

public class Student {

	//public static void main(String[] args) {
		// TODO Auto-generated method stub

	//}
	
	private String name;
	private String city;
	private Double marks;
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public Student(String name, String city, Double salary) {
		super();
		this.name = name;
		this.city = city;
		this.marks = marks;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Double getSalary() {
		return marks;
	}
	public void setSalary(Double salary) {
		this.marks = marks;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", city=" + city + ", marks=" + marks + "]";
	}
	
	
	

}
