package com.java.training;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class ListMain {
	public static void main(String[] args)
	{
		List<Student> studentList=new ArrayList<>();	
		Student employee1 = new Student("Divya","Tiruvallur",40.0);
		studentList.add(employee1);
		studentList.add(new Student("Ashwin","coimbatore",80.0));
		studentList.add(new Student("Ramu","chennai",60.0));
		studentList.add(new Student("Nila","madurai",80.0));
		studentList.add(new Student("diya","Ooty",70.0));
		
		//System.out.println(studentList);
		//Line by line
		Iterator<Student> it=studentList.iterator();
		while(it.hasNext()) {
			Student stud = it.next();
			System.out.println(stud);
		}
		
		for(Student stud1:studentList) {
			System.out.println(stud1);
		}
		System.out.println("//////////REVERSE ORDER/////////////////");
		ListIterator<Student> listIt=studentList.listIterator(studentList.size());
		while (listIt.hasPrevious()) {
			Student student = listIt.previous();
			System.out.println(student);
			
		}
	}
}