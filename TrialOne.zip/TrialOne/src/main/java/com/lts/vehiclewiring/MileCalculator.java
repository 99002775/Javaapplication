package com.lts.vehiclewiring;

public interface MileCalculator {
	void showMileage(int km, int qty); 
		
	

}
