package com.lts.vehiclewiring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component

public class VehicleDetails {
	@Autowired
	@Qualifier("car")
MileCalculator car;
	@Autowired
	@Qualifier("bike")
MileCalculator bike;
	int choice=1;
public void getMileage(int km, int qty) {
	if(choice==1) 
	 car.showMileage(km, qty);
	else
		bike.showMileage(km, qty);
	
	
}
}
