package com.lts.vehiclewiring;

import org.springframework.stereotype.Component;

@Component

public class Car implements MileCalculator{

	@Override
	public void showMileage(int km, int qty) {
		// TODO Auto-generated method stub
		System.out.println("car mileage is "+km/qty);
		
	}

	

	

}
