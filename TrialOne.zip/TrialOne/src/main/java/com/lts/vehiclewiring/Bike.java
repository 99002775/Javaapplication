package com.lts.vehiclewiring;

import org.springframework.stereotype.Component;

@Component
public class Bike implements MileCalculator{

	@Override
	public void showMileage(int km, int qty) {
		System.out.println("Bike mileage is "+km/qty);
		// TODO Auto-generated method stub
		
	}

	

	

}
