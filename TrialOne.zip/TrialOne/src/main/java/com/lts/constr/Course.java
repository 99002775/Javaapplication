package com.lts.constr;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component

public class Course {
	String coursename;
	Integer price;
	public String getCoursename() {
		return coursename;
	}
	@Value("${student.course.name}")
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public Integer getPrice() {
		return price;
	}
	@Value("${student.course.price}")
	public void setPrice(Integer price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Course [coursename=" + coursename + ", price=" + price + "]";
	}

	
}
