package com.studentapp.controllers;

public class StudentResponseController {

}
