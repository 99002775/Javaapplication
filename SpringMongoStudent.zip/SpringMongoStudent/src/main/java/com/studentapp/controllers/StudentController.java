package com.studentapp.controllers;

public class StudentController {

}
