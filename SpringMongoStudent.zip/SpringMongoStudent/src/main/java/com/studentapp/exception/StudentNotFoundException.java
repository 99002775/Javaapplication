package com.studentapp.exception;

public class StudentNotFoundException extends Exception {

	public StudentNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentNotFoundException(String message) {
		super( message);
		// TODO Auto-generated constructor stub
	}

}
