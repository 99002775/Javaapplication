package com.studentapp.exception;

public class GlobalExceptionHandler {
	

}
