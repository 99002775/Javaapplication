package com.studentapp.service;

import java.util.List;


import com.studentapp.exception.StudentNotFoundException;
import com.studentapp.model.Student;

public class StudentServiceImpl implements StudentService {

	@Override
	public Student addStudent(Student student) {
		// TODO Auto-generated method stub
		Student newstudent = studentRepository.save(student);
		return newstudent;
		return null;
	}

	@Override
	public boolean deleteStudent(Integer studId) throws StudentNotFoundException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Student getStudentById(Integer StudentId) throws StudentNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Student UpdateStudent(Student student) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> getAllStudents() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> getStudentbyName(String name) throws StudentNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> getStudentbyDepartment(String department) throws StudentNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> findByNameDepartment(String name, String department) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> findStudentsByNameAndStudId(String name, Integer studid) {
		// TODO Auto-generated method stub
		return null;
	}

}
