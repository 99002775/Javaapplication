package com.studentapp.service;

import java.util.List;

import com.studentapp.exception.StudentNotFoundException;
import com.studentapp.model.Student;

public interface StudentService {
	Student addStudent(Student student);
	boolean deleteStudent(Integer studId)throws StudentNotFoundException;
	Student getStudentById(Integer StudentId)throws StudentNotFoundException;
	Student UpdateStudent(Student student);
	


    List<Student> getAllStudents();
    List<Student> getStudentbyName(String name) throws StudentNotFoundException;
    List<Student> getStudentbyDepartment(String department)throws StudentNotFoundException;
    
    List<Student>findByNameDepartment(String name, String department);
	List<Student> findStudentsByNameAndStudId(String name, Integer studid);
	
	

}
