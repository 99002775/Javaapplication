package com.studentapp.model;

public class Student {
	Integer studId;
	String name;
	String department;
	Integer age;
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Student(Integer studId, String name, String department, Integer age) {
		super();
		this.studId = studId;
		this.name = name;
		this.department = department;
		this.age = age;
	}
	public Integer getStudId() {
		return studId;
	}
	public void setStudId(Integer studId) {
		this.studId = studId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "Student [studId=" + studId + ", name=" + name + ", department=" + department + ", age=" + age + "]";
	}
	
	
	
	}
