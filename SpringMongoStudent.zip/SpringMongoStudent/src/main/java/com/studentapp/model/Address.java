package com.studentapp.model;

public class Address {
	String city;
	String satate;
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Address(String city, String satate) {
		super();
		this.city = city;
		this.satate = satate;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getSatate() {
		return satate;
	}
	public void setSatate(String satate) {
		this.satate = satate;
	}
	@Override
	public String toString() {
		return "Address [city=" + city + ", satate=" + satate + "]";
	}
	

}
