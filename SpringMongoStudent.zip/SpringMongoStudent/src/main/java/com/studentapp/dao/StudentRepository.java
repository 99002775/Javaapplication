package com.studentapp.dao;

import java.util.List;

import com.studentapp.model.Student;

public interface StudentRepository {
	
	List<Student>findByAge(Integer age);

}
