package com.java.training;

import java.util.ArrayList;
import java.util.Collections;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee1 = new Employee("diya","chennai",101);
		Employee employee2 = new Employee("dev","coimbatore",102);
		Employee employee3 = new Employee("ammu","bangalore",103);
		Employee employee4 = new Employee("rubesh","Ooty",104);
		
		ArrayList<Employee> employeeList = new ArrayList<>();
		employeeList.add(employee1);
		employeeList.add(employee2);
		employeeList.add(employee3);
		employeeList.add(employee4);
		
		for (Employee emp : employeeList) {
			System.out.println(emp);
			
		}
		
		Collections.sort(employeeList);
		System.out.println("sorted list using comparable");
		for (Employee emp : employeeList) {
			System.out.println(emp);
			
		}


	}

}
